import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class CrabWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class CrabWorld extends World
{

    /**
     * Constructor for objects of class CrabWorld.
     * 
     */
    public CrabWorld()
    {    
        super(560, 560, 1); 
        prepare();
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Crab crab = new Crab();
        addObject(crab,179,334);
        Worm worm = new Worm();
        addObject(worm,65,56);
        Worm worm2 = new Worm();
        addObject(worm2,152,120);
        Worm worm3 = new Worm();
        addObject(worm3,205,193);
        worm2.setLocation(153,124);
        worm2.setLocation(132,137);
        Worm worm4 = new Worm();
        addObject(worm4,276,259);
        Worm worm5 = new Worm();
        addObject(worm5,360,328);
        Worm worm6 = new Worm();
        addObject(worm6,431,405);
        Worm worm7 = new Worm();
        addObject(worm7,498,478);
        worm7.setLocation(506,515);
        worm6.setLocation(432,447);
        worm5.setLocation(356,370);
        worm4.setLocation(276,304);
        worm3.setLocation(216,243);
        worm2.setLocation(146,189);
        worm.setLocation(48,74);
        worm2.setLocation(109,141);
        worm3.setLocation(167,210);
        worm4.setLocation(306,157);
        worm3.setLocation(71,493);
        worm2.setLocation(480,52);
        worm4.setLocation(243,200);
        worm5.setLocation(511,291);
        worm6.setLocation(276,460);
        Worm worm8 = new Worm();
        addObject(worm8,285,90);
        worm4.setLocation(140,206);
        Lobster lobster = new Lobster();
        addObject(lobster,390,179);
    }
}
