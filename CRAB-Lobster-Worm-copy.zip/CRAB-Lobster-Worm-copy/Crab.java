import greenfoot.*;

/**
 * This class defines a crab. Crabs live on the beach.
 */
public class Crab extends Actor
{
    
    
    public void act()
    {
        move(2);
        
        if (Greenfoot.isKeyDown("left")){
        turn(-3);}
        if (Greenfoot.isKeyDown("right")){
        turn(3);}
        
        Actor worm;
        worm = getOneObjectAtOffset(0, 0, Worm.class);
        if(worm != null)
    {
        World world;
        world = getWorld();
        world.removeObject(worm);
            
    }
    }
    
    
}

